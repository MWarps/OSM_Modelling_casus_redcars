/*
 * bank.h
 *
 *  Created on: 29 Oct 2020
 *      Author: Merlijn
 */

#ifndef BANK_H_
#define BANK_H_

class bank {
public:
	virtual ~bank();
};

#endif /* BANK_H_ */
