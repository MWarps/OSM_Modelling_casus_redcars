/*
 * Car.cpp
 *
 *  Created on: 29 Oct 2020
 *      Author: yodas
 */

#include "Car.h"

Car::Car() {
	// TODO Auto-generated constructor stub

}

Car::~Car() {
	// TODO Auto-generated destructor stub
}

std::vector<Car> Car::showAvailableCars() {
}

void Car::setAvailable(bool available) {
}
