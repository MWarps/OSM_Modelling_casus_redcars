/*
 * Reservering.cpp
 *
 *  Created on: 29 Oct 2020
 *      Author: yodas
 */

#include "Reservering.h"

Reservering::Reservering() {
	// TODO Auto-generated constructor stub

}

Reservering::~Reservering() {
	// TODO Auto-generated destructor stub
}

bool Reservering::checkAvailableCars(Cars car, int tijdsduur) {
	return false;
}

float Reservering::calculatePrice(bool abbonnement, std::string tijdsType,
		int tijdsDuur) {
	return prijs;
}

void Reservering::finishReservation() {
}

void Reservering::pay(float prijs) {
}
