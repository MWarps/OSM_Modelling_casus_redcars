/*
 * Car.cpp
 *
 *  Created on: 29 Oct 2020
 *      Author: Merlijn
 */

#include "Car.h"

Car::Car() {
	// TODO Auto-generated constructor stub

}

Car::~Car() {
	// TODO Auto-generated destructor stub
}

