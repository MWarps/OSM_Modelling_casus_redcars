/*
 * AutoControl.cpp
 *
 *  Created on: 29 Oct 2020
 *      Author: Merlijn
 */

#include "AutoControl.h"

AutoControl::~AutoControl() {
	// TODO Auto-generated destructor stub
}

AutoControl::AutoControl() {
	// TODO Auto-generated constructor stub

}

void AutoControl::unlock() {
}

void AutoControl::lock() {
}

void AutoControl::startEngine() {
}
