/*
 * Klant.cpp
 *
 *  Created on: 29 Oct 2020
 *      Author: Merlijn
 */

#include "Klant.h"

Klant::Klant() {
	// TODO Auto-generated constructor stub

}

Klant::~Klant() {
	// TODO Auto-generated destructor stub
}

